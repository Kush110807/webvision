from playwright.sync_api import sync_playwright, expect
from pathlib import Path
import json, traceback
ROOT=Path(__file__).resolve().parent
BASE='http://127.0.0.1:5185'
results=[];logs=[];responsive=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 def run(name,fn):
  context=browser.new_context(viewport={'width':1440,'height':1000});page=context.new_page();page.set_default_timeout(6000)
  page.on('pageerror',lambda e:logs.append({'test':name,'kind':'pageerror','message':str(e)}))
  page.on('console',lambda m:logs.append({'test':name,'kind':m.type,'message':m.text}) if m.type in ['error','warning'] else None)
  page.on('requestfailed',lambda req:logs.append({'test':name,'kind':'requestfailed','url':req.url,'message':req.failure}))
  page.on('response',lambda res:logs.append({'test':name,'kind':'http','status':res.status,'url':res.url}) if res.status>=400 else None)
  try:
   fn(page);page.screenshot(path=str(ROOT/(name+'.png')),full_page=True);results.append({'test':name,'result':'PASS'})
  except Exception as e:
   page.screenshot(path=str(ROOT/(name+'-failure.png')),full_page=True);results.append({'test':name,'result':'FAIL','error':traceback.format_exc()})
  context.close()
 def visit(page,route):
  res=page.goto(BASE+route);assert res.status==200
 def step(page,n):expect(page.locator('.so-step-content h2')).to_contain_text('Step '+str(n))
 def home(page):
  visit(page,'/');page.get_by_role('button',name='Explore available services').click();expect(page.get_by_text('Select a state first')).to_be_visible()
  page.get_by_role('combobox').fill('Delhi');page.get_by_role('option').get_by_role('button').click();expect(page.get_by_role('combobox')).to_have_value('Delhi')
  page.get_by_role('button',name='Explore available services').click();page.wait_for_url(BASE+'/delhi');expect(page.locator('h1')).to_contain_text('Delhi')
 def journey(page):
  visit(page,'/journey');step(page,1);cont=page.get_by_role('button',name='Continue',exact=True);prev=page.get_by_role('button',name='Previous',exact=True)
  cont.click();step(page,2);prev.click();step(page,1);cont.click();cont.click();step(page,3)
  cont.click();step(page,3);expect(page.get_by_text('Cannot continue yet')).to_be_visible()
  required=page.locator('label.so-check-item').filter(has=page.locator('.so-badge-essential'));assert required.count()>0
  for label in required.all():label.get_by_role('checkbox').check()
  cont.click();step(page,4)
  vehicle=page.locator('#so-vehicle');age=page.locator('#so-age');vehicle.select_option(index=1);age.select_option(index=1);page.get_by_role('checkbox').check();v=vehicle.input_value();a=age.input_value()
  cont.click();step(page,5);page.reload();step(page,5);prev.click();step(page,4);expect(vehicle).to_have_value(v);expect(age).to_have_value(a);expect(page.get_by_role('checkbox')).to_be_checked()
  cont.click();cont.click();step(page,6);page.get_by_role('button',name='Start a new journey').click();page.wait_for_url(BASE+'/');visit(page,'/journey');step(page,1)
  stored=page.evaluate("JSON.parse(localStorage.getItem('sarathiOne.journey.v1'))");assert stored['step']==1 and not any(stored['checklist'].values()) and not any(stored['applicant'].values()), stored
 def status(page):
  visit(page,'/status');inp=page.locator('#so-ref');inp.fill('S1-DEMO-100001');page.get_by_role('button',name='Search',exact=True).click();result=page.get_by_role('region',name='Demo application result');expect(result).to_be_visible();expect(result).to_contain_text('S1-DEMO-100001');expect(page.get_by_text('Simulated record')).to_be_visible();expect(page.locator('.so-timeline li')).to_have_count(5)
  inp.fill('INVALID123');expect(result).to_have_count(0);page.get_by_role('button',name='Search',exact=True).click();expect(page.get_by_text('Lookup failed')).to_be_visible();expect(page.get_by_text('That does not look like a valid reference',exact=False)).to_be_visible()
 def original(page):
  visit(page,'/original');expect(page.locator('.main .header')).to_be_visible();expect(page.locator('.main img').first).to_be_visible();page.get_by_role('button',name='Close',exact=True).click();page.get_by_role('link',name='Back to SARATHI ONE home').click();page.wait_for_url(BASE+'/');expect(page.get_by_role('button',name='Explore available services')).to_be_visible()
 def mobile(page):
  page.set_viewport_size({'width':375,'height':900});visit(page,'/');toggle=page.get_by_role('button',name='Open menu');toggle.click();expect(page.locator('#so-navigation')).to_be_visible();page.get_by_role('button',name='Close menu').click();expect(toggle).to_have_attribute('aria-expanded','false')
  toggle.click();page.keyboard.press('Escape');expect(toggle).to_be_focused();expect(toggle).to_have_attribute('aria-expanded','false');toggle.click();page.locator('#so-navigation').get_by_role('link',name='Application Status',exact=True).click();page.wait_for_url(BASE+'/status');expect(page.get_by_role('button',name='Open menu')).to_have_attribute('aria-expanded','false')
  for width in [375,320,768,1440]:
   page.set_viewport_size({'width':width,'height':900})
   for route in ['/','/delhi','/journey','/status','/state-selection','/services/driving-licence']:
    visit(page,route);page.wait_for_timeout(80);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,route)
    # Inspect horizontal bounds of visible, non-decorative controls/cards/text blocks.
    clipped=page.locator('.so-app').evaluate('''el => [...el.querySelectorAll('button,input,select,h1,h2,p,.so-card')].filter(e => {const r=e.getBoundingClientRect();return r.width>0 && r.height>0 && getComputedStyle(e).visibility!=='hidden' && (r.left < -1 || r.right > innerWidth+1)}).map(e=>({tag:e.tagName,text:e.textContent.slice(0,70)}))''')
    assert not clipped,(width,route,clipped)
    responsive.append({'width':width,'route':route,'overflow':'PASS','horizontalBounds':'PASS'})
    page.screenshot(path=str(ROOT/f'viewport-{width}-{route.strip("/").replace("/","-") or "home"}.png'),full_page=True)
 run('QA-01-homepage',home);run('QA-02-journey',journey);run('QA-03-status',status);run('QA-04-original',original);run('QA-05-mobile',mobile)
 browser.close()
(ROOT/'results.json').write_text(json.dumps({'tests':results,'responsive':responsive},indent=2));(ROOT/'browser-logs.json').write_text(json.dumps(logs,indent=2));print(json.dumps(results,indent=2));print('Browser log entries:',len(logs))
