State-picker guidance had low contrast, tablet journey progress consumed excessive vertical space, and saved progress could claim completion without valid prerequisites. This change improves those existing flows while preserving the redesign and original comparison.

- Raise helper-copy contrast, compact the journey stepper, associate state errors with the input, scroll keyboard-active state options, and supply a local favicon.
- Normalize progress on both read/write, validate actual applicant option IDs, disclose unavailable storage, and explicitly label non-Delhi selections as a Delhi demo.
- Preserve all existing sample references, status behavior, routing, original-page source and package lockfile. No backend or optional print feature added.

Validation: npm ci and production build pass; existing 42 browser regression entries pass; five acceptance flows and 21 extended checks pass; 30 route/viewport geometry checks pass; eight targeted v2 browser entries and seven reliability groups pass. Before/after screenshots captured at 320/375/768/1024/1440px. Existing audit still reports five advisories (one high, four moderate); no forced upgrade. Full details in WEBVISION_V2_ENHANCEMENT_HANDOFF.md.

Do not merge automatically; review the verified enhancement separately from main.
