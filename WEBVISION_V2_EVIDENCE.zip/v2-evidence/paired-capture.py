from pathlib import Path
from playwright.sync_api import sync_playwright
r=Path(__file__).parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for phase,port in [('before',5186),('after',5187)]:
  for w in [320,375,768,1024,1440]:
   for route in ['/','/delhi','/status','/state-selection','/journey']:
    c=b.new_context(viewport={'width':w,'height':950});page=c.new_page();page.goto(f'http://127.0.0.1:{port}'+route)
    key=route.strip('/') or 'home'
    if route=='/':page.get_by_role('combobox').fill('Del')
    if route=='/status':page.get_by_role('button',name='S1-DEMO-100002',exact=True).click()
    if route=='/journey':
     key='journey-4';cont=page.get_by_role('button',name='Continue',exact=True);cont.click();cont.click()
     for check in page.get_by_role('checkbox').all():check.check()
     cont.click()
    page.evaluate("window.scrollTo({top:0,behavior:'instant'})");page.wait_for_timeout(100);page.screenshot(path=str(r/phase/f'paired-{key}-{w}.png'),full_page=True);c.close()
 b.close()
