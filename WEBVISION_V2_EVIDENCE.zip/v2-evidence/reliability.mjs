import assert from 'node:assert/strict';
import { normalizeJourney, loadJourney, saveJourney } from '../src/utils/storage.js';
import { validateApplicantDetails } from '../src/utils/validation.js';
import { CHECKLIST_CATEGORIES, VEHICLE_CATEGORIES, AGE_BANDS } from '../src/data/learnerLicence.js';
let count=0;
function check(name,fn){fn();count++;console.log('PASS '+name);}
check('Non-object and array saved roots rejected',()=>{for(const v of [null,[],1,true,'text'])assert.equal(normalizeJourney(v),null)});
check('Malformed field types never crash normalization',()=>{for(const v of [null,[],1,true,'text',{}])assert.ok(normalizeJourney({applicant:v,checklist:v,step:v,stateCode:v,serviceId:v}))});
check('Unknown fields and sensitive-shaped extra keys are discarded on save',()=>{let payload;globalThis.window={localStorage:{setItem:(_,v)=>payload=JSON.parse(v)}};assert.equal(saveJourney({step:1,name:'test-only',applicant:{name:'test-only'},checklist:{unexpected:true}}),true);assert.equal(payload.name,undefined);assert.equal(payload.applicant.name,undefined);assert.equal(payload.checklist.unexpected,undefined)});
check('Invalid identifiers and truthy confirmation rejected',()=>{const x=normalizeJourney({stateCode:'bad',serviceId:'bad',applicant:{vehicleCategory:'bad',ageBand:'bad',confirmed:'true'}});assert.equal(x.stateCode,null);assert.equal(x.serviceId,null);assert.equal(x.applicant.confirmed,false);assert.equal(Object.keys(validateApplicantDetails({vehicleCategory:'bad',ageBand:'bad',confirmed:'true'})).length,3)});
check('Impossible completion resumes at earliest missing prerequisite',()=>{assert.equal(normalizeJourney({step:6}).step,3);const checklist=Object.fromEntries(CHECKLIST_CATEGORIES.flatMap(c=>c.items).map(i=>[i.id,true]));assert.equal(normalizeJourney({step:6,checklist}).step,4);assert.equal(normalizeJourney({step:6,checklist,applicant:{vehicleCategory:VEHICLE_CATEGORIES[0].id,ageBand:AGE_BANDS[0].id,confirmed:true}}).step,6)});
check('Unavailable storage read/write returns safely',()=>{globalThis.window={get localStorage(){throw new Error('simulated denied storage')}};assert.equal(loadJourney(),null);assert.equal(saveJourney({}),false)});
check('JSON primitives and malformed JSON recover',()=>{for(const raw of ['null','[]','true','4','"string"','{invalid']){globalThis.window={localStorage:{getItem:()=>raw}};assert.equal(loadJourney(),null)}});
console.log(`${count} reliability groups PASS`);
