from playwright.sync_api import sync_playwright, expect
from pathlib import Path
import json,traceback
ROOT=Path(__file__).resolve().parent
results=[];logs=[];images=[];labels=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=b.new_context(viewport={'width':1440,'height':1000});page=context.new_page();page.set_default_timeout(5000)
 page.on('pageerror',lambda e: logs.append({'kind':'pageerror','message':str(e)}))
 page.on('console',lambda m:logs.append({'kind':m.type,'message':m.text,'location':m.location}) if m.type in ['error','warning'] else None)
 page.on('response',lambda r:logs.append({'kind':'http','status':r.status,'url':r.url}) if r.status>=400 else None)
 page.on('requestfailed',lambda r:logs.append({'kind':'network','url':r.url,'message':r.failure}))
 def go(route):page.goto('http://127.0.0.1:5187'+route)
 def test(name,fn):
  try:fn();results.append({'check':name,'result':'PASS'})
  except Exception:results.append({'check':name,'result':'FAIL','detail':traceback.format_exc()})
 def clear():
  go('/');page.evaluate('localStorage.clear()');page.reload()
 clear()
 def keyboard():
  picker=page.get_by_role('combobox');picker.fill('del');picker.press('ArrowDown');assert picker.get_attribute('aria-activedescendant');picker.press('Enter');expect(picker).to_have_value('Delhi');page.get_by_role('button',name='Clear selected state').click();expect(picker).to_have_value('');picker.fill('zzzz');expect(page.get_by_text('No state or Union Territory matches',exact=False)).to_be_visible();picker.press('Escape');expect(picker).to_have_attribute('aria-expanded','false')
 test('State arrows/Enter, clear, no matches and Escape',keyboard)
 def focus():
  page.reload();page.keyboard.press('Tab');expect(page.get_by_role('link',name='Skip to main content')).to_be_focused();outline=page.locator(':focus').evaluate('e=>({style:getComputedStyle(e).outlineStyle,width:getComputedStyle(e).outlineWidth})');assert outline['style']!='none' and outline['width']!='0px';page.keyboard.press('Enter');expect(page.locator('#so-main')).to_be_focused()
 test('Keyboard skip link visible outline and main focus',focus)
 for href in ['/','/delhi','/journey','/status','/original']:
  def nav():
   go('/');page.locator('#so-navigation a[href="'+href+'"]').click();page.wait_for_url('http://127.0.0.1:5187'+href)
  test('Primary navbar '+href,nav)
 for ref in ['S1-DEMO-100001','S1-DEMO-100002','S1-DEMO-100003']:
  def sample():
   go('/status');page.get_by_role('button',name=ref,exact=True).click();expect(page.get_by_role('region',name='Demo application result')).to_contain_text(ref);expect(page.get_by_text('Simulated record')).to_be_visible()
  test('Status sample '+ref,sample)
 def unknown():
  page.locator('#so-ref').fill('S1-DEMO-999999');page.get_by_role('button',name='Search',exact=True).click();expect(page.get_by_text('No demo application matches',exact=False)).to_be_visible()
 test('Unknown demo reference',unknown)
 for route,title in [('/services/driving-licence','Driving Licence (Permanent)'),('/services/licence-renewal','Renewal of Driving Licence'),('/services/not-a-service','Service not found'),('/missing-page','Page not found')]:
  def service():go(route);expect(page.locator('h1')).to_have_text(title)
  test('Service/fallback '+route,service)
 def recovery():
  go('/');page.evaluate('''localStorage.setItem('sarathiOne.journey.v1',JSON.stringify({step:999,stateCode:'bad',serviceId:'bad',applicant:{name:'remove-me',confirmed:'false'},checklist:null}))''');go('/journey');expect(page.locator('.so-step-content h2')).to_contain_text('Step 1');saved=page.evaluate("JSON.parse(localStorage.getItem('sarathiOne.journey.v1'))");assert saved['stateCode']==None and saved['serviceId']==None and saved['applicant']['confirmed']==False and 'name' not in saved['applicant']
 test('Invalid saved data normalization and unwanted field removal',recovery)
 def corrupt():
  page.evaluate("localStorage.setItem('sarathiOne.journey.v1','{broken')");page.reload();expect(page.locator('.so-step-content h2')).to_contain_text('Step 1')
 test('Corrupt saved JSON recovery',corrupt)
 def applicant():
  clear();go('/journey');cont=page.get_by_role('button',name='Continue',exact=True);cont.click();cont.click()
  for x in page.get_by_role('checkbox').all():x.check()
  cont.click();cont.click();expect(page.locator('.so-step-content h2')).to_contain_text('Step 4');expect(page.get_by_text('Cannot continue yet')).to_be_visible();page.locator('#so-vehicle').select_option(index=1);page.locator('#so-age').select_option(index=1);cont.click();expect(page.locator('.so-step-content h2')).to_contain_text('Step 4');page.get_by_role('checkbox').check();cont.click();expect(page.locator('.so-step-content h2')).to_contain_text('Step 5')
 test('Applicant choices and confirmation individually block advancement',applicant)
 def government():
  links=[]
  for route in ['/','/delhi','/journey','/status','/services/driving-licence','/services/licence-renewal']:
   go(route)
   for a in page.locator('a[href^="https://"]').all():
    href=a.get_attribute('href');assert href.startswith(('https://parivahan.gov.in','https://sarathi.parivahan.gov.in/'));assert a.get_attribute('target')=='_blank';assert {'noopener','noreferrer'}.issubset(set((a.get_attribute('rel') or '').split()));links.append(href)
  assert any('stateSelection.do' in x for x in links)
 test('Government HTTPS link destinations and new-tab isolation',government)
 # DOM label and sensitive-input review. Results saved with evidence, no form submissions.
 def forms():
  for route in ['/','/journey','/status','/state-selection']:
   go(route)
   for x in page.locator('input,select,textarea').all():
    data=x.evaluate('''e=>({tag:e.tagName,type:e.type,id:e.id,labels:[...(e.labels||[])].map(x=>x.innerText),aria:e.getAttribute('aria-label')})''');labels.append({'route':route,**data});assert data['labels'] or data['aria'];assert data['type'] not in ['password','file','tel','email','date']
 test('Visible route form labels; no sensitive-input types',forms)
 # Visual fixtures preserve actual controls; journey screenshot progression is exercised here.
 clear();go('/journey');cont=page.get_by_role('button',name='Continue',exact=True)
 for step in range(1,7):
  for width in [320,375,768,1024,1440]:
   page.set_viewport_size({'width':width,'height':950});page.evaluate("window.scrollTo({top:0,behavior:'instant'})");page.wait_for_timeout(80);page.screenshot(path=str(ROOT/f'journey-step-{step}-{width}.png'),full_page=True)
  if step==3:
   for x in page.get_by_role('checkbox').all():x.check()
  if step==4:
   page.locator('#so-vehicle').select_option(index=1);page.locator('#so-age').select_option(index=1);page.get_by_role('checkbox').check()
  if step<6:cont.click()
 clear()
 for width in [320,375,768,1024,1440]:
  page.set_viewport_size({'width':width,'height':950})
  for route in ['/','/delhi','/status','/state-selection','/services/driving-licence','/original']:
   go(route)
   if route=='/original':page.get_by_role('button',name='Close',exact=True).click()
   if route=='/status':page.get_by_role('button',name='S1-DEMO-100002',exact=True).click()
   if route=='/':page.get_by_role('combobox').fill('Del')
   page.wait_for_timeout(80)
   key=route.strip('/').replace('/','-') or 'home'
   page.screenshot(path=str(ROOT/f'visual-{key}-{width}.png'),full_page=True)
   for x in page.locator('img').all():
    info=x.evaluate('e=>({url:e.currentSrc,loaded:e.complete && e.naturalWidth>0})');images.append({'route':route,'width':width,**info})
  if width in [320,375,768]:
   go('/');page.get_by_role('button',name='Open menu').click();page.screenshot(path=str(ROOT/f'menu-open-{width}.png'),full_page=True)
 def imagecheck():assert all(x['loaded'] for x in images),[x for x in images if not x['loaded']]
 test('All rendered image elements load across visual capture routes',imagecheck)
 b.close()
(ROOT/'extended-results.json').write_text(json.dumps(results,indent=2));(ROOT/'extended-browser-logs.json').write_text(json.dumps(logs,indent=2));(ROOT/'image-results.json').write_text(json.dumps(images,indent=2));(ROOT/'form-labels.json').write_text(json.dumps(labels,indent=2));print(json.dumps(results,indent=2))
