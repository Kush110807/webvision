from playwright.sync_api import sync_playwright,expect
from pathlib import Path
import json,traceback
r=Path(__file__).parent;out=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 def run(name,fn,deny=False):
  c=b.new_context(viewport={'width':375,'height':950})
  if deny:c.add_init_script("Storage.prototype.setItem = function(){throw new Error('simulated unavailable storage')}")
  page=c.new_page();page.set_default_timeout(5000)
  try:fn(page);out.append({'check':name,'result':'PASS'})
  except Exception:out.append({'check':name,'result':'FAIL','detail':traceback.format_exc()})
  c.close()
 def go(page,path):page.goto('http://127.0.0.1:5187'+path)
 def errors(page):
  go(page,'/');page.get_by_role('button',name='Explore available services').click();inp=page.get_by_role('combobox');expect(inp).to_have_attribute('aria-invalid','true');desc=inp.get_attribute('aria-describedby');expect(page.locator('[id="'+desc+'"]').get_by_text('Please select a State or Union Territory before continuing.')).to_be_visible();page.screenshot(path=str(r/'after/home-validation-375.png'),full_page=True)
  inp.fill('no-such-state');expect(inp).to_have_attribute('aria-invalid','false');expect(page.get_by_text('No state or Union Territory matches',exact=False)).to_be_visible()
 run('State error associated with input and cleared during correction',errors)
 def dropdown(page):
  go(page,'/');i=page.get_by_role('combobox');i.click()
  for _ in range(28):i.press('ArrowDown')
  page.wait_for_timeout(150);active=i.get_attribute('aria-activedescendant');info=page.locator('[id="'+active+'"]').evaluate('e=>{const a=e.getBoundingClientRect(),b=e.closest("ul").getBoundingClientRect();return {top:a.top,bottom:a.bottom,listTop:b.top,listBottom:b.bottom}}');assert info['top']>=info['listTop'] and info['bottom']<=info['listBottom'],info
  i.press('Enter');assert i.input_value()
 run('Long state-list keyboard navigation scrolls active option into view',dropdown)
 def nondelhi(page):
  go(page,'/');page.get_by_role('combobox').fill('Maharashtra');page.get_by_role('combobox').press('Enter');page.get_by_role('button',name='Explore available services').click();expect(page.get_by_text('Delhi demonstration only',exact=True)).to_be_visible();page.screenshot(path=str(r/'after/non-delhi-dashboard-375.png'),full_page=True)
  go(page,'/journey');expect(page.get_by_text('Delhi demonstration only',exact=True)).to_be_visible();expect(page.get_by_text('not Maharashtra government services.',exact=False)).to_be_visible();page.screenshot(path=str(r/'after/non-delhi-journey-375.png'),full_page=True)
 run('Non-Delhi selection clearly labelled on dashboard and journey',nondelhi)
 def denial(page):
  go(page,'/journey');expect(page.get_by_text('Progress is not saved — browser storage unavailable')).to_be_visible();page.get_by_role('button',name='Continue',exact=True).click();expect(page.locator('.so-step-content h2')).to_contain_text('Step 2')
 run('Unavailable storage is disclosed while in-session journey remains usable',denial,True)
 def compact(page):
  for w in [320,375,768,1024,1440]:
   page.set_viewport_size({'width':w,'height':950});go(page,'/journey');rows=page.locator('.so-stepper').evaluate('e=>({height:e.getBoundingClientRect().height,columns:getComputedStyle(e).gridTemplateColumns.split(" ").length})');assert rows['columns']==(3 if w<=780 else 6);assert rows['height']<190,rows
 run('Journey grid uses two rows on mobile/tablet and one on desktop',compact)
 def favicon(page):
  go(page,'/');link=page.locator('link[rel="icon"]');expect(link).to_have_attribute('href','/favicon.svg');res=page.request.get('http://127.0.0.1:5187/favicon.svg');assert res.status==200 and '<svg' in res.text()
 run('Declared local favicon resolves',favicon)
 def contrast(page):
  go(page,'/');data=page.locator('.so-state-panel-footnote').evaluate('e=>({color:getComputedStyle(e).color,bg:getComputedStyle(e.closest(".so-landing-state-panel")).backgroundColor})')
  import re
  def lum(c):
   a=[int(x)/255 for x in re.findall(r'\d+',c)[:3]];a=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in a];return sum(v*k for v,k in zip(a,[.2126,.7152,.0722]))
  ratio=(lum(data['bg'])+.05)/(lum(data['color'])+.05);assert ratio>=4.5,ratio;out.append({'check':'Measured helper contrast ratio','result':'PASS','ratio':round(ratio,2)})
 run('State helper contrast meets 4.5:1',contrast)
 b.close()
(r/'v2-browser-results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
